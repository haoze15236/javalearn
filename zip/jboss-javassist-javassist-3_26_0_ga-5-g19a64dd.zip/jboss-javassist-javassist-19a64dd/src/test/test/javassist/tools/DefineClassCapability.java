/*
 * This is used as a capability for running CtClass#toClass().
 */
package test.javassist.tools;

public class DefineClassCapability {
}
