package test4;

@Anno1 public class Anno {
    @Anno1 public int value;
    @Anno1 public int foo() { return 0; }
}
