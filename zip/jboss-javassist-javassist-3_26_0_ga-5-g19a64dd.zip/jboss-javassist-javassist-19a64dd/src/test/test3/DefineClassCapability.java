/*
 * This is used as a capability for running CtClass#toClass().
 */
package test3;

public class DefineClassCapability {
}
